/*
 * E2MMA — Point d'entrée principal
 * Arduino Giga R1 WiFi (STM32H747)
 *
 * Flux : FileSystem lit un fichier XML → ParserXML crée les widgets
 *        → Userinterface les affiche via LVGL
 */

#include "Arduino_H7_Video.h"
#include "Arduino_GigaDisplayTouch.h"
#include "lvgl.h"

#include "E2MMA.h"
#include "FileSystem.h"
#include "ParserXML.h"
#include "Userinterface.h"
#include "Widget.h"

// ─── Matériel ────────────────────────────────────────────────────
Arduino_H7_Video         Display(800, 480, GigaDisplayShield);
Arduino_GigaDisplayTouch TouchDetector;

// ── Suivi du touch pour détecter le swipe bord supérieur ─────────
// On mémorise la position Y au moment du PRESS pour savoir si le
// geste a démarré depuis le bord haut (<= 10px), sans interférer
// avec les widgets LVGL.
static int16_t  touch_start_y    = -1;
static bool     touch_is_pressed = false;

static void touch_read_cb(lv_indev_t* indev, lv_indev_data_t* data) {
    GDTpoint_t pts[5];
    uint8_t n = TouchDetector.getTouchPoints(pts);
    if (n > 0) {
        data->point.x = pts[0].x;
        data->point.y = pts[0].y;
        data->state   = LV_INDEV_STATE_PRESSED;
        if (!touch_is_pressed) {
            // Nouveau contact : mémoriser Y de départ
            touch_start_y    = pts[0].y;
            touch_is_pressed = true;
        }
    } else {
        data->state      = LV_INDEV_STATE_RELEASED;
        touch_is_pressed = false;
        // Ne pas remettre touch_start_y à -1 ici :
        // _pressing_cb lit touch_start_y pendant le glissement
    }
}

// ─── Sous-classe concrète ─────────────────────────────────────────
class E2mmaApp : public E2mma {
public:
    lv_obj_t* screen_list   = nullptr;
    lv_obj_t* screen_wait   = nullptr;

    bool          usb_was_connected   = false;
    bool          usb_checking_paused = false;
    unsigned long last_check          = 0;
    int           disco_count         = 0;

    static char file_content_buf[MAX_CONTENT];

    // ── Boucle principale ────────────────────────────────────────
    void run() override {
        userinterface->tick();

        if (!usb_checking_paused && millis() - last_check > 500) {
            last_check = millis();
            bool connected_now = fileSystem->isConnected();
            if (usb_was_connected && !connected_now) {
                disco_count++;
                if (disco_count >= 6) {
                    Serial.println("[USB] Deconnexion confirmee !");
                    disco_count       = 0;
                    usb_was_connected = false;
                    fileSystem->unmount();
                    userinterface->clearWidgets();
                    if (screen_list) { lv_obj_del(screen_list); screen_list = nullptr; }
                    show_screen_wait();
                }
            } else {
                disco_count = 0;
                if (connected_now) usb_was_connected = true;
            }
        }
        delay(5);
    }

    // ── Helper topbar ────────────────────────────────────────────
    lv_obj_t* make_topbar(lv_obj_t* parent, const char* title,
                           lv_event_cb_t left_cb,
                           lv_event_cb_t right_cb, const char* right_label) {
        lv_obj_t* bar = lv_obj_create(parent);
        lv_obj_set_size(bar, 800, 58);
        lv_obj_align(bar, LV_ALIGN_TOP_MID, 0, 0);
        lv_obj_set_style_bg_color(bar, lv_color_hex(0x313244), 0);
        lv_obj_set_style_border_width(bar, 0, 0);
        lv_obj_set_style_radius(bar, 0, 0);
        lv_obj_clear_flag(bar, LV_OBJ_FLAG_SCROLLABLE);

        if (title && strlen(title) > 0) {
            lv_obj_t* lbl = lv_label_create(bar);
            lv_label_set_text(lbl, title);
            lv_obj_set_style_text_color(lbl, lv_color_hex(0xCDD6F4), 0);
            lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
            lv_obj_align(lbl, LV_ALIGN_CENTER, 0, 0);
        }
        if (left_cb) {
            lv_obj_t* btn = lv_button_create(bar);
            lv_obj_set_size(btn, 110, 38);
            lv_obj_align(btn, LV_ALIGN_LEFT_MID, 10, 0);
            lv_obj_set_style_bg_color(btn, lv_color_hex(0xE53935), 0);
            lv_obj_set_style_radius(btn, 8, 0);
            lv_obj_add_event_cb(btn, left_cb, LV_EVENT_CLICKED, this);
            lv_obj_t* lbl = lv_label_create(btn);
            lv_label_set_text(lbl, "Retour");
            lv_obj_set_style_text_color(lbl, lv_color_hex(0xFFFFFF), 0);
            lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
            lv_obj_center(lbl);
        }
        if (right_cb && right_label) {
            lv_obj_t* btn = lv_button_create(bar);
            lv_obj_set_size(btn, 130, 38);
            lv_obj_align(btn, LV_ALIGN_RIGHT_MID, -10, 0);
            lv_obj_set_style_bg_color(btn, lv_color_hex(0x89B4FA), 0);
            lv_obj_set_style_radius(btn, 8, 0);
            lv_obj_add_event_cb(btn, right_cb, LV_EVENT_CLICKED, this);
            lv_obj_t* lbl = lv_label_create(btn);
            lv_label_set_text(lbl, right_label);
            lv_obj_set_style_text_color(lbl, lv_color_hex(0x1E1E2E), 0);
            lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
            lv_obj_center(lbl);
        }
        return bar;
    }

    // ── Écran d'attente USB ──────────────────────────────────────
    void show_screen_wait() {
        if (screen_wait) { lv_obj_del(screen_wait); screen_wait = nullptr; }
        screen_wait = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(screen_wait, lv_color_hex(0x1E1E2E), 0);

        lv_obj_t* msg = lv_label_create(screen_wait);
        lv_label_set_text(msg, "En attente de connexion USB...\nBranchez la cle et appuyez sur Connecter.");
        lv_obj_set_style_text_color(msg, lv_color_hex(0xCDD6F4), 0);
        lv_obj_set_style_text_font(msg, &lv_font_montserrat_14, 0);
        lv_label_set_long_mode(msg, LV_LABEL_LONG_WRAP);
        lv_obj_set_width(msg, 500);
        lv_obj_set_style_text_align(msg, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_align(msg, LV_ALIGN_CENTER, 0, -30);

        lv_obj_t* btn = lv_button_create(screen_wait);
        lv_obj_set_size(btn, 160, 50);
        lv_obj_align(btn, LV_ALIGN_CENTER, 0, 60);
        lv_obj_set_style_bg_color(btn, lv_color_hex(0x89B4FA), 0);
        lv_obj_set_style_radius(btn, 8, 0);
        lv_obj_add_event_cb(btn, _connect_cb, LV_EVENT_CLICKED, this);
        lv_obj_t* lbl = lv_label_create(btn);
        lv_label_set_text(lbl, "Connecter");
        lv_obj_set_style_text_color(lbl, lv_color_hex(0x1E1E2E), 0);
        lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
        lv_obj_center(lbl);
        lv_screen_load(screen_wait);
    }

    // ── Écran liste fichiers ─────────────────────────────────────
    void build_screen_list() {
        screen_list = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(screen_list, lv_color_hex(0x1E1E2E), 0);
        make_topbar(screen_list, "Choisir un fichier XML",
                    nullptr, _refresh_cb, "Actualiser");

        int count = fileSystem->getFileCount();
        if (count == 0) {
            lv_obj_t* msg = lv_label_create(screen_list);
            lv_label_set_text(msg, fileSystem->isReady()
                ? "Aucun fichier sur la cle USB."
                : "Cle USB non detectee.\nAppuyez sur Actualiser.");
            lv_obj_set_style_text_color(msg, lv_color_hex(0xF38BA8), 0);
            lv_obj_set_style_text_font(msg, &lv_font_montserrat_14, 0);
            lv_label_set_long_mode(msg, LV_LABEL_LONG_WRAP);
            lv_obj_set_width(msg, 600);
            lv_obj_align(msg, LV_ALIGN_CENTER, 0, 0);
            return;
        }

        lv_obj_t* cont = lv_obj_create(screen_list);
        lv_obj_set_size(cont, 780, 400);
        lv_obj_align(cont, LV_ALIGN_TOP_MID, 0, 66);
        lv_obj_set_style_bg_color(cont, lv_color_hex(0x1E1E2E), 0);
        lv_obj_set_style_border_width(cont, 0, 0);
        lv_obj_set_style_pad_row(cont, 6, 0);
        lv_obj_set_style_pad_all(cont, 4, 0);
        lv_obj_set_flex_flow(cont, LV_FLEX_FLOW_COLUMN);

        for (int i = 0; i < count; i++) {
            lv_obj_t* row = lv_button_create(cont);
            lv_obj_set_size(row, 760, 52);
            lv_obj_set_style_bg_color(row, lv_color_hex(0x313244), 0);
            lv_obj_set_style_bg_color(row, lv_color_hex(0x45475A), LV_STATE_PRESSED);
            lv_obj_set_style_radius(row, 8, 0);
            lv_obj_add_event_cb(row, _file_btn_cb, LV_EVENT_CLICKED, (void*)(intptr_t)i);

            lv_obj_t* lbl = lv_label_create(row);
            lv_label_set_text(lbl, fileSystem->getFileName(i));
            lv_obj_set_style_text_color(lbl, lv_color_hex(0xCDD6F4), 0);
            lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
            lv_label_set_long_mode(lbl, LV_LABEL_LONG_DOT);
            lv_obj_set_width(lbl, 720);
            lv_obj_align(lbl, LV_ALIGN_LEFT_MID, 12, 0);
        }
    }

    // ── Topbar UI ────────────────────────────────────────────────
    lv_obj_t*  ui_topbar     = nullptr;
    bool       topbar_visible = false;
    lv_timer_t* _hide_timer  = nullptr;   // timer auto-hide 5s

    void loadXmlFile(int idx) {
        bool ok = fileSystem->readFile(fileSystem->getFilePath(idx),
                                       file_content_buf, sizeof(file_content_buf));
        if (!ok) {
            Serial.println("[XML] Lecture fichier echouee");
            return;
        }

        Serial.print("[XML] Parsing : ");
        Serial.println(fileSystem->getFileName(idx));

        int n = parserXML->parse(file_content_buf, userinterface);
        if (n < 0) {
            Serial.println("[XML] Erreur parsing");
            return;
        }

        lv_obj_t* scr = userinterface->getScreen();

        // ── Topbar créée EN DERNIER → au-dessus dans le Z-order ──────
        // Elle démarre à y=-58 (hors écran) et descend à y=0 au swipe.
        ui_topbar = lv_obj_create(scr);
        lv_obj_set_size(ui_topbar, 800, 58);
        lv_obj_set_style_bg_color(ui_topbar, lv_color_hex(0x313244), 0);
        lv_obj_set_style_border_width(ui_topbar, 0, 0);
        lv_obj_set_style_radius(ui_topbar, 0, 0);
        lv_obj_set_style_shadow_width(ui_topbar, 4, 0);
        lv_obj_set_style_shadow_ofs_y(ui_topbar, 4, 0);
        lv_obj_set_style_shadow_color(ui_topbar, lv_color_hex(0x000000), 0);
        lv_obj_set_style_shadow_opa(ui_topbar, 80, 0);
        lv_obj_clear_flag(ui_topbar, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_set_pos(ui_topbar, 0, -58);

        // Bouton Retour
        lv_obj_t* btn = lv_button_create(ui_topbar);
        lv_obj_set_size(btn, 110, 38);
        lv_obj_align(btn, LV_ALIGN_LEFT_MID, 10, 0);
        lv_obj_set_style_bg_color(btn, lv_color_hex(0xE53935), 0);
        lv_obj_set_style_radius(btn, 8, 0);
        lv_obj_set_style_border_width(btn, 0, 0);
        lv_obj_add_event_cb(btn, _ui_back_cb, LV_EVENT_CLICKED, this);
        lv_obj_t* lbl = lv_label_create(btn);
        lv_label_set_text(lbl, "Retour");
        lv_obj_set_style_text_color(lbl, lv_color_hex(0xFFFFFF), 0);
        lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
        lv_obj_center(lbl);

        // Titre centré
        lv_obj_t* title = lv_label_create(ui_topbar);
        lv_label_set_text(title, fileSystem->getFileName(idx));
        lv_obj_set_style_text_color(title, lv_color_hex(0xCDD6F4), 0);
        lv_obj_set_style_text_font(title, &lv_font_montserrat_14, 0);
        lv_obj_align(title, LV_ALIGN_CENTER, 0, 0);

        // ── Détection swipe via LV_EVENT_PRESSING ─────────────────────
        //
        // LV_EVENT_PRESSING est envoyé en continu pendant le glissement
        // mais NE vole PAS les events des widgets enfants (contrairement
        // à LV_EVENT_GESTURE + GESTURE_BUBBLE). Les sliders et listes
        // continuent de recevoir leurs events normalement.
        //
        // La position de départ du touch est mémorisée dans touch_read_cb
        // (touch_start_y). Si ce départ est dans les 10 premiers pixels
        // du haut de l'écran et que le delta Y dépasse 40px → swipe détecté.
        // ─────────────────────────────────────────────────────────────
        lv_obj_add_event_cb(scr, _pressing_cb, LV_EVENT_PRESSING, this);

        topbar_visible = false;
        touch_start_y  = -1;

        lv_screen_load(scr);
        if (screen_list) { lv_obj_del(screen_list); screen_list = nullptr; }
    }

    // Anime la topbar vers y_target
    // Si on l'affiche (y_target == 0) : arme un timer one-shot 5s
    // qui la cache automatiquement. Si on la cache : annule ce timer.
    void animateTopbar(int y_target) {
        lv_anim_t a;
        lv_anim_init(&a);
        lv_anim_set_var(&a, ui_topbar);
        lv_anim_set_exec_cb(&a, [](void* obj, int32_t val) {
            lv_obj_set_y((lv_obj_t*)obj, val);
        });
        lv_anim_set_values(&a, lv_obj_get_y(ui_topbar), y_target);
        lv_anim_set_duration(&a, 250);
        lv_anim_set_path_cb(&a, lv_anim_path_ease_out);
        lv_anim_start(&a);

        // Annuler le timer precedent dans tous les cas
        if (_hide_timer) {
            lv_timer_delete(_hide_timer);
            _hide_timer = nullptr;
        }

        if (y_target == 0) {
            // Topbar affichee -> armer auto-hide apres 5 secondes
            _hide_timer = lv_timer_create([](lv_timer_t* t) {
                E2mmaApp* self = (E2mmaApp*)lv_timer_get_user_data(t);
                self->_hide_timer    = nullptr;
                self->topbar_visible = false;
                self->animateTopbar(-58);
            }, 5000, this);
            lv_timer_set_repeat_count(_hide_timer, 1);
        }
    }

    // ── Callback pressing ─────────────────────────────────────────
    static void _pressing_cb(lv_event_t* e) {
        E2mmaApp* self = (E2mmaApp*)lv_event_get_user_data(e);
        if (!self->ui_topbar) return;

        // Ignorer si le geste n'a pas démarré depuis le bord supérieur
        if (touch_start_y < 0 || touch_start_y > 10) return;

        lv_indev_t* indev = lv_indev_active();
        lv_point_t  pos;
        lv_indev_get_point(indev, &pos);

        int32_t delta = pos.y - touch_start_y;

        if (!self->topbar_visible && delta > 40) {
            // Swipe vers le bas depuis le bord → afficher la topbar
            self->topbar_visible = true;
            self->animateTopbar(0);
            touch_start_y = -1; // consommer le geste
        } else if (self->topbar_visible && delta < -40) {
            // Swipe vers le haut → cacher
            self->topbar_visible = false;
            self->animateTopbar(-58);
            touch_start_y = -1;
        }
    }

    // ── Callbacks LVGL statiques ─────────────────────────────────

    static void _connect_cb(lv_event_t* e) {
        E2mmaApp* self = (E2mmaApp*)lv_event_get_user_data(e);
        if (self->screen_wait) { lv_obj_del(self->screen_wait); self->screen_wait = nullptr; }
        if (self->screen_list) { lv_obj_del(self->screen_list); self->screen_list = nullptr; }

        lv_obj_t* splash = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(splash, lv_color_hex(0x1E1E2E), 0);
        lv_obj_t* slbl = lv_label_create(splash);
        lv_label_set_text(slbl, "Connexion USB en cours...");
        lv_obj_set_style_text_color(slbl, lv_color_hex(0xCDD6F4), 0);
        lv_obj_set_style_text_font(slbl, &lv_font_montserrat_14, 0);
        lv_obj_align(slbl, LV_ALIGN_CENTER, 0, 0);
        lv_screen_load(splash);
        lv_timer_handler();
        delay(20);

        self->fileSystem->unmount();
        bool ok = self->fileSystem->mount(15000);
        if (ok) { self->fileSystem->listFiles(); self->usb_was_connected = true; }
        else    { self->usb_was_connected = false; }
        lv_obj_del(splash);

        if (ok) { self->build_screen_list(); lv_screen_load(self->screen_list); }
        else    { self->show_screen_wait(); }
    }

    static void _list_back_cb(lv_event_t* e) {
        E2mmaApp* self = (E2mmaApp*)lv_event_get_user_data(e);
        self->fileSystem->unmount();
        self->usb_was_connected = false;
        if (self->screen_list) { lv_obj_del(self->screen_list); self->screen_list = nullptr; }
        self->show_screen_wait();
    }

    static void _refresh_cb(lv_event_t* e) {
        E2mmaApp* self = (E2mmaApp*)lv_event_get_user_data(e);
        self->usb_checking_paused = true;
        if (self->screen_list) { lv_obj_del(self->screen_list); self->screen_list = nullptr; }
        self->fileSystem->listFiles();
        self->build_screen_list();
        lv_screen_load(self->screen_list);
        delay(300);
        self->usb_checking_paused = false;
    }

    static void _ui_back_cb(lv_event_t* e) {
        E2mmaApp* self = (E2mmaApp*)lv_event_get_user_data(e);
        // Annuler le timer auto-hide avant de quitter l'ecran
        if (self->_hide_timer) {
            lv_timer_delete(self->_hide_timer);
            self->_hide_timer = nullptr;
        }
        self->ui_topbar      = nullptr;
        self->topbar_visible = false;
        self->userinterface->clearWidgets();
        self->build_screen_list();
        lv_screen_load(self->screen_list);
    }

    static void _file_btn_cb(lv_event_t* e) {
        int idx = (int)(intptr_t)lv_event_get_user_data(e);
        extern E2mmaApp app;
        app.loadXmlFile(idx);
    }
};

// ─── Définition du buffer statique ───────────────────────────────
char E2mmaApp::file_content_buf[MAX_CONTENT];

// ─── Instance globale ─────────────────────────────────────────────
E2mmaApp app;

// ─── Arduino entry points ─────────────────────────────────────────

void setup() {
    Serial.begin(115200);
    delay(1000);

    if (Display.begin() != 0) {
        Serial.println("ERREUR Display.begin()");
        while (1);
    }
    TouchDetector.begin();

    lv_indev_t* indev = lv_indev_create();
    lv_indev_set_type(indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(indev, touch_read_cb);

    app.setup();
    app.show_screen_wait();

    bool ok = false;
    unsigned long t0 = millis();
    while (millis() - t0 < 15000) {
        lv_timer_handler();
        delay(5);
        if (app.getFileSystem()->mount(200)) { ok = true; break; }
    }

    if (ok) {
        app.getFileSystem()->listFiles();
        app.usb_was_connected = true;
        app.build_screen_list();
        lv_screen_load(app.screen_list);
    }
}

void loop() {
    app.run();
}
