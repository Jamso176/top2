/**
 * @file ParserXML.h
 * @brief Déclaration du parser XML minimaliste pour l'interface E2MMA.
 *
 * Ce module lit un buffer XML décrivant une interface graphique et
 * instancie les widgets LVGL correspondants dans un objet Userinterface.
 *
 * @section xml_format Format XML supporté
 * @code{.xml}
 * <model ref="E2MMA">
 *   <ui>
 *     <button id="1">
 *       <x>10</x> <y>20</y> <width>50</width> <height>50</height>
 *       <text>+</text>
 *       <color>#5562e7</color>
 *       <colortext>#000000</colortext>
 *       <hiden>false</hiden>
 *       <action>incr_slider</action>
 *       <args><arg>1</arg><arg>2</arg></args>
 *     </button>
 *     <slider id="1"> ... </slider>
 *     <label  id="1"> ... </label>
 *     <textarea id="1"> ... </textarea>
 *   </ui>
 * </model>
 * @endcode
 *
 * @note Le parser est volontairement simple : pas de DOM, pas d'allocation
 *       dynamique hors des widgets créés. Il travaille directement sur le
 *       buffer C-string passé en entrée (lecture seule).
 */

#ifndef PARSERXML_H
#define PARSERXML_H

#include <Arduino.h>
#include "Widget.h"
#include "Userinterface.h"

/**
 * @class ParserXML
 * @brief Parser XML léger dédié à la description d'interfaces E2MMA.
 *
 * La classe offre un unique point d'entrée public (parse()) qui :
 *  -# Localise le bloc @c \<ui\> dans le buffer fourni.
 *  -# Itère sur chaque type de widget supporté (button, slider, label…).
 *  -# Instancie les objets E2mmaWidgets::Widget correspondants.
 *  -# Les injecte dans l'objet Userinterface via addWidget().
 *
 * Toutes les méthodes d'analyse (getChildText, findBlock, etc.) sont
 * privées et sans état : le parseur peut être réutilisé plusieurs fois
 * sur des buffers différents sans réinitialisation.
 */
class ParserXML {
public:
    /**
     * @brief Constructeur par défaut.
     *
     * N'alloue aucune ressource. L'initialisation effective est réalisée
     * dans begin().
     */
    ParserXML();

    /**
     * @brief Destructeur.
     *
     * Le parser ne possède aucune ressource dynamique propre ;
     * le destructeur est présent par symétrie et pour une éventuelle
     * dérivation future.
     */
    ~ParserXML();

    /**
     * @brief Initialise le parser et affiche un message de diagnostic.
     *
     * Doit être appelé une seule fois depuis E2mma::setup() avant tout
     * appel à parse().
     */
    void begin();

    /**
     * @brief Parse un buffer XML et peuple l'interface utilisateur.
     *
     * Efface d'abord tous les widgets existants dans @p ui (clearWidgets()),
     * puis parcourt le bloc @c \<ui\> du buffer XML pour créer et enregistrer
     * chaque widget trouvé.
     *
     * L'ordre de création respecte la profondeur d'affichage LVGL :
     * labels et sliders en premier (fond), boutons en dernier (avant-plan).
     *
     * @param[in] xmlBuffer  Buffer C-string contenant le XML complet.
     *                       Doit rester valide pendant toute la durée de l'appel.
     *                       Non modifié (lecture seule).
     * @param[in,out] ui     Interface cible. Ses widgets existants seront
     *                       supprimés avant l'injection des nouveaux.
     *
     * @return Nombre de widgets créés et ajoutés avec succès,
     *         ou @c -1 en cas d'erreur (pointeur nul, bloc \<ui\> absent).
     */
    int parse(const char* xmlBuffer, Userinterface* ui);

private:
    /**
     * @brief Extrait le contenu texte d'un élément XML @c \<tag\>valeur\</tag\>.
     *
     * Recherche la première occurrence de @c \<tag\> dans @p block, copie
     * la valeur comprise entre la balise ouvrante et la balise fermante
     * dans @p out, puis supprime les espaces/retours à la ligne en début
     * et fin de chaîne (trim).
     *
     * @param[in]  block    Portion de XML dans laquelle chercher.
     * @param[in]  tag      Nom de la balise sans chevrons (ex. @c "color").
     * @param[out] out      Buffer de sortie pour la valeur extraite.
     * @param[in]  outSize  Taille maximale du buffer @p out (octet terminal inclus).
     *
     * @return @c true si la balise a été trouvée et la valeur copiée,
     *         @c false sinon (@p out reste inchangé).
     */
    bool getChildText(const char* block, const char* tag,
                      char* out, size_t outSize);

    /**
     * @brief Extrait et convertit en entier le contenu d'une balise XML.
     *
     * Appelle getChildText() puis convertit la chaîne avec @c atoi().
     *
     * @param[in] block   Portion de XML dans laquelle chercher.
     * @param[in] tag     Nom de la balise sans chevrons (ex. @c "x").
     * @param[in] defVal  Valeur retournée si la balise est absente ou vide.
     *                    Vaut @c 0 par défaut.
     *
     * @return Valeur entière extraite, ou @p defVal si introuvable.
     */
    int getChildInt(const char* block, const char* tag, int defVal = 0);

    /**
     * @brief Convertit une chaîne de couleur en entier 32 bits 0xRRGGBB.
     *
     * Deux formats sont acceptés :
     *  - **Hexadécimal HTML** : @c "#RRGGBB"  → @c strtoul sur les 6 chiffres.
     *  - **Triplet décimal**  : @c "R,G,B"   → calcul manuel des composantes.
     *
     * @param[in] colorStr  Chaîne de couleur à convertir. Peut être @c nullptr
     *                      ou vide, auquel cas @p defVal est retourné.
     * @param[in] defVal    Valeur par défaut si la conversion échoue.
     *                      Vaut @c 0x888888 par défaut.
     *
     * @return Couleur au format @c 0xRRGGBB, ou @p defVal en cas d'échec.
     */
    uint32_t parseColor(const char* colorStr, uint32_t defVal = 0x888888);

    /**
     * @brief Localise et délimite un bloc XML @c \<tagName …\>…\</tagName\>.
     *
     * Recherche la première balise ouvrante dont le nom correspond exactement
     * à @p tagName (le caractère suivant le nom doit être @c >, espace,
     * @c \\n ou @c \\r pour éviter les faux positifs sur des préfixes).
     *
     * @param[in]  src       Chaîne dans laquelle chercher (début de recherche).
     * @param[in]  tagName   Nom du tag sans chevrons (ex. @c "button").
     * @param[out] blockEnd  Si non nul, reçoit un pointeur sur le premier
     *                       caractère @b après la balise fermante
     *                       @c \</tagName\>. Utile pour enchaîner les
     *                       recherches dans une boucle.
     *
     * @return Pointeur sur le premier caractère du @b contenu du bloc
     *         (juste après @c >), ou @c nullptr si le bloc est introuvable
     *         ou mal formé.
     *
     * @note Le pointeur retourné pointe dans @p src ; aucune copie n'est
     *       effectuée.
     */
    const char* findBlock(const char* src, const char* tagName,
                          const char** blockEnd);

    /**
     * @brief Instancie le widget E2mmaWidgets approprié depuis un bloc XML.
     *
     * Lit les attributs communs (@c x, @c y, @c width, @c height, @c color,
     * @c colortext, @c text, @c hiden) puis, selon @p tagName, lit les
     * attributs spécifiques et appelle le constructeur correspondant.
     *
     * Types de widgets supportés :
     * | @p tagName   | Classe créée                        |
     * |--------------|-------------------------------------|
     * | @c button    | E2mmaWidgets::PushButton            |
     * | @c slider    | E2mmaWidgets::Slider                |
     * | @c label     | E2mmaWidgets::Label                 |
     * | @c textarea  | E2mmaWidgets::TextArea              |
     * | @c switch    | E2mmaWidgets::Switch                |
     * | @c led       | E2mmaWidgets::Led                   |
     * | @c keyboard  | E2mmaWidgets::Keyboard              |
     *
     * @param[in] tagName  Nom du tag XML identifiant le type de widget.
     * @param[in] block    Contenu du bloc XML (entre balises ouvrante et
     *                     fermante), tel que retourné par findBlock().
     *
     * @return Pointeur vers le widget alloué sur le tas, ou @c nullptr si
     *         @p tagName n'est pas reconnu. L'appelant est responsable de
     *         la durée de vie de l'objet (ownership transféré à Userinterface
     *         via addWidget()).
     */
    E2mmaWidgets::Widget* makeWidget(const char* tagName, const char* block);
};

#endif // PARSERXML_H
