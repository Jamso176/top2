#include "E2MMA.h"
#include "FileSystem.h"
#include "ParserXML.h"
#include "Userinterface.h"
// #include "CurvePlotting.h"
// #include "Io.h"

E2mma::E2mma()
    : parserXML(nullptr)
    , curvePlotting(nullptr)
    , fileSystem(nullptr)
    , io(nullptr)
    , userinterface(nullptr)
{
}

void E2mma::setup()
{
    fileSystem    = new E2FileSystem();
    fileSystem->begin();

    parserXML     = new ParserXML();
    parserXML->begin();

    userinterface = new Userinterface();
    userinterface->begin();

    // io            = new Io();         io->begin();
    // curvePlotting = new CurvePlotting(); curvePlotting->begin();
}

E2mma::~E2mma()
{
    delete userinterface;
    delete curvePlotting;
    delete parserXML;
    delete fileSystem;
    delete io;
}
