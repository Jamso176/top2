#include "FileSystem.h"

// ═══════════════════════════════════════════════════════════════
//  USBFileSystem
// ═══════════════════════════════════════════════════════════════

USBFileSystem::USBFileSystem()
    : _msd(nullptr), _fs("usb"), _ready(false), _fileCount(0)
{
}

USBFileSystem::~USBFileSystem() {
    unmount();
}

bool USBFileSystem::begin(unsigned long timeoutMs) {
    if (_ready) return true;

    Serial.println("[USB] Activation port USB-A...");
    pinMode(PA_15, OUTPUT);
    digitalWrite(PA_15, HIGH);
    delay(200);

    if (_msd != nullptr) {
        delete _msd;
        _msd = nullptr;
        delay(100);
    }

    _msd = new USBHostMSD();
    if (!_msd) {
        Serial.println("[USB] Erreur allocation USBHostMSD");
        return false;
    }

    Serial.println("[USB] Attente cle USB...");
    unsigned long t = millis();
    while (!_msd->connect()) {
        if (millis() - t > timeoutMs) {
            Serial.println("[USB] TIMEOUT — cle non detectee");
            return false;
        }
        Serial.println("[USB] ...");
        delay(500);
    }
    Serial.println("[USB] Cle detectee !");

    int err = _fs.mount(_msd);
    if (err != 0) {
        Serial.print("[USB] Erreur montage FAT : ");
        Serial.println(err);
        return false;
    }

    _ready = true;
    _fileCount = 0;
    Serial.println("[USB] Monte sur /usb/");
    return true;
}

bool USBFileSystem::isReady()      const { return _ready; }
bool USBFileSystem::isConnected()        { return _msd ? _msd->connected() : false; }
int  USBFileSystem::getFileCount() const { return _fileCount; }

const char* USBFileSystem::getFileName(int i) const {
    if (i < 0 || i >= _fileCount) return "";
    return _fileNames[i];
}

const char* USBFileSystem::getFilePath(int i) const {
    if (i < 0 || i >= _fileCount) return "";
    return _filePaths[i];
}

int USBFileSystem::listFiles(const char* dir) {
    _fileCount = 0;
    if (!_ready) return 0;

    DIR* d = opendir(dir);
    if (!d) {
        Serial.print("[USB] opendir echoue : ");
        Serial.println(dir);
        return 0;
    }

    struct dirent* entry;
    while ((entry = readdir(d)) != nullptr && _fileCount < MAX_FILES) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;
        if (entry->d_type == DT_DIR)
            continue;

        strncpy(_fileNames[_fileCount], entry->d_name, MAX_FILENAME - 1);
        _fileNames[_fileCount][MAX_FILENAME - 1] = '\0';

        snprintf(_filePaths[_fileCount], sizeof(_filePaths[_fileCount]),
                 "%s/%s", dir, entry->d_name);
        _fileCount++;
    }
    closedir(d);

    Serial.print("[USB] Fichiers trouves : ");
    Serial.println(_fileCount);
    return _fileCount;
}

bool USBFileSystem::readFile(const char* path, char* outBuf, size_t bufSize) {
    if (!_ready || !outBuf || bufSize == 0) return false;
    FILE* f = fopen(path, "r");
    if (!f) {
        Serial.print("[USB] fopen echoue : ");
        Serial.println(path);
        return false;
    }
    size_t n = fread(outBuf, 1, bufSize - 1, f);
    outBuf[n] = '\0';
    fclose(f);
    Serial.print("[USB] Lu ");
    Serial.print((int)n);
    Serial.println(" octets");
    return true;
}

void USBFileSystem::unmount() {
    _fs.unmount();
    _ready     = false;
    _fileCount = 0;
    Serial.println("[USB] Demonte — pret pour reconnexion");
}

// ═══════════════════════════════════════════════════════════════
//  E2FileSystem  (alias FileSystem — délègue à USBFileSystem)
// ═══════════════════════════════════════════════════════════════

E2FileSystem::E2FileSystem() {}
E2FileSystem::~E2FileSystem() {}

void E2FileSystem::begin() {
    Serial.println("[FileSystem] Initialise (montage USB a la demande)");
}

USBFileSystem& E2FileSystem::usb() { return _usb; }

bool        E2FileSystem::mount(unsigned long timeoutMs)                   { return _usb.begin(timeoutMs); }
void        E2FileSystem::unmount()                                        { _usb.unmount(); }
bool        E2FileSystem::isReady()     const                              { return _usb.isReady(); }
bool        E2FileSystem::isConnected()                                    { return _usb.isConnected(); }
int         E2FileSystem::listFiles(const char* dir)                       { return _usb.listFiles(dir); }
const char* E2FileSystem::getFileName(int i)  const                        { return _usb.getFileName(i); }
const char* E2FileSystem::getFilePath(int i)  const                        { return _usb.getFilePath(i); }
int         E2FileSystem::getFileCount()      const                        { return _usb.getFileCount(); }
bool        E2FileSystem::readFile(const char* path, char* buf, size_t sz) { return _usb.readFile(path, buf, sz); }
