#ifndef USERINTERFACE_H
#define USERINTERFACE_H

#include <Arduino.h>
#include "lvgl.h"
#include "Widget.h"

#define MAX_WIDGETS 64

class Userinterface {
public:
    Userinterface();
    ~Userinterface();

    // Appelé par E2mma::setup()
    void begin();

    // Appelé par E2mmaApp::run() — traite les events LVGL
    void tick();

    // Ajoute un widget et le construit dans le screen courant
    void addWidget(E2mmaWidgets::Widget* widget);

    // Efface tous les widgets (nouveau fichier chargé)
    void clearWidgets();

    // Accès au screen principal
    lv_obj_t* getScreen() { return _screen; }

private:
    E2mmaWidgets::Widget* _widgets[MAX_WIDGETS];
    int                   _widgetCount;
    lv_obj_t*             _screen;
};

#endif // USERINTERFACE_H
