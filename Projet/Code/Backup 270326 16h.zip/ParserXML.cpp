/**
 * @file ParserXML.cpp
 * @brief Implémentation du parser XML minimaliste E2MMA.
 *
 * Stratégie générale :
 *  - Pas de DOM ni d'arbre syntaxique : le buffer est parcouru une seule
 *    fois par type de widget grâce à des recherches de sous-chaînes
 *    (strstr), ce qui limite les allocations mémoire sur microcontrôleur.
 *  - Toutes les chaînes intermédiaires sont stockées sur la pile (buffers
 *    statiques dimensionnés au strict nécessaire).
 *  - L'ownership des widgets créés est immédiatement transféré à
 *    Userinterface::addWidget() ; aucun widget n'est conservé par le parser.
 */

#include "ParserXML.h"
#include <stdlib.h>
#include <string.h>

// ─────────────────────────────────────────────────────────────────
//  Constructeur / Destructeur
// ─────────────────────────────────────────────────────────────────

/** @brief Constructeur trivial — aucune ressource à initialiser. */
ParserXML::ParserXML()  {}

/** @brief Destructeur trivial — aucune ressource à libérer. */
ParserXML::~ParserXML() {}

// ─────────────────────────────────────────────────────────────────
//  begin
// ─────────────────────────────────────────────────────────────────

/**
 * @brief Initialise le parser.
 *
 * Actuellement limitée à un message de diagnostic sur le port série.
 * Peut être étendue pour pré-allouer des ressources si nécessaire.
 */
void ParserXML::begin() {
    Serial.println("[XML] ParserXML initialise");
}

// ─────────────────────────────────────────────────────────────────
//  getChildText
// ─────────────────────────────────────────────────────────────────

/**
 * @brief Extrait le texte contenu entre @c \<tag\> et @c \</tag\>.
 *
 * Algorithme :
 *  1. Construit les chaînes de recherche @c "<tag>" et @c "</tag>".
 *  2. Localise la balise ouvrante dans @p block via strstr.
 *  3. Avance le curseur juste après le @c '>' de la balise ouvrante.
 *  4. Localise la balise fermante.
 *  5. Copie le contenu (tronqué à @p outSize - 1 si nécessaire).
 *  6. Supprime les espaces et retours à la ligne en début et fin (trim).
 *
 * @note La fonction ne gère pas les balises imbriquées du même nom :
 *       elle s'arrête à la première occurrence de @c \</tag\>.
 */
bool ParserXML::getChildText(const char* block, const char* tag,
                              char* out, size_t outSize) {
    char open[64], close[64];
    /* Construction des balises ouvrante et fermante */
    snprintf(open,  sizeof(open),  "<%s>",  tag);
    snprintf(close, sizeof(close), "</%s>", tag);

    /* Recherche de la balise ouvrante */
    const char* start = strstr(block, open);
    if (!start) return false;
    start += strlen(open);   /* Pointe sur le premier caractère du contenu */

    /* Recherche de la balise fermante */
    const char* end = strstr(start, close);
    if (!end) return false;

    /* Copie du contenu (troncature si trop long pour le buffer) */
    size_t len = (size_t)(end - start);
    if (len >= outSize) len = outSize - 1;
    strncpy(out, start, len);
    out[len] = '\0';

    /* Trim début : suppression des espaces/sauts de ligne en tête */
    char* p = out;
    while (*p == ' ' || *p == '\n' || *p == '\r') p++;
    if (p != out) memmove(out, p, strlen(p) + 1);

    /* Trim fin : suppression des espaces/sauts de ligne en queue */
    size_t l = strlen(out);
    while (l > 0 && (out[l-1]==' '||out[l-1]=='\n'||out[l-1]=='\r')) out[--l]='\0';

    return true;
}

// ─────────────────────────────────────────────────────────────────
//  getChildInt
// ─────────────────────────────────────────────────────────────────

/**
 * @brief Extrait un entier depuis une balise XML enfant.
 *
 * Délègue l'extraction de texte à getChildText() puis convertit
 * la chaîne obtenue avec @c atoi(). Si la balise est absente ou
 * vide, @p defVal est retourné directement.
 *
 * @warning @c atoi() retourne 0 pour toute chaîne non numérique ;
 *          il est donc impossible de distinguer la valeur 0 d'une
 *          valeur mal formée sans passer par @p defVal ≠ 0.
 */
int ParserXML::getChildInt(const char* block, const char* tag, int defVal) {
    char buf[32];
    if (!getChildText(block, tag, buf, sizeof(buf))) return defVal;
    return atoi(buf);
}

// ─────────────────────────────────────────────────────────────────
//  parseColor
// ─────────────────────────────────────────────────────────────────

/**
 * @brief Convertit une chaîne de couleur en valeur 32 bits @c 0xRRGGBB.
 *
 * Deux formats sont reconnus :
 *
 * **Format hexadécimal HTML** (@c "#RRGGBB") :
 * @code
 *   "#5562e7"  →  0x5562E7
 * @endcode
 * La conversion utilise @c strtoul() en base 16 sur les caractères
 * qui suivent le @c '#'.
 *
 * **Format triplet décimal** (@c "R,G,B") :
 * @code
 *   "128,64,255"  →  0x8040FF
 * @endcode
 * Chaque composante est extraite avec @c atoi() et @c strchr(',').
 *
 * Si la chaîne est vide, nulle, ou ne correspond à aucun format,
 * @p defVal est retourné.
 */
uint32_t ParserXML::parseColor(const char* s, uint32_t defVal) {
    if (!s || s[0] == '\0') return defVal;

    /* Format "#RRGGBB" */
    if (s[0] == '#') return (uint32_t)strtoul(s + 1, nullptr, 16);

    /* Format "R,G,B" : présence d'une virgule comme discriminant */
    if (strchr(s, ',')) {
        int r = atoi(s);
        const char* g = strchr(s, ','); if (!g) return defVal; g++;
        const char* b = strchr(g, ','); if (!b) return defVal; b++;
        return ((uint32_t)r << 16) | ((uint32_t)atoi(g) << 8) | (uint32_t)atoi(b);
    }

    return defVal;
}

// ─────────────────────────────────────────────────────────────────
//  findBlock
// ─────────────────────────────────────────────────────────────────

/**
 * @brief Localise un bloc @c \<tagName …\>…\</tagName\> dans une chaîne XML.
 *
 * Algorithme de discrimination des tags (évite les faux positifs) :
 *
 *  - Recherche la sous-chaîne @c "<tagName" avec strstr.
 *  - Vérifie que le caractère immédiatement suivant est l'un de :
 *    @c '>', @c ' ', @c '\\n', @c '\\r'. Cela garantit que le tag trouvé
 *    est bien @p tagName et non un tag qui en est un préfixe
 *    (ex. @c "button" ne doit pas matcher @c "buttongroup").
 *  - Avance jusqu'au premier @c '>' pour dépasser les attributs éventuels
 *    (@c id="…", etc.).
 *  - Recherche ensuite la balise fermante @c "</tagName>".
 *
 * Exemple d'utilisation en boucle pour itérer sur tous les @c \<button\> :
 * @code
 *   const char* cursor = uiBlock;
 *   const char* blockEnd;
 *   const char* content;
 *   while ((content = findBlock(cursor, "button", &blockEnd)) != nullptr) {
 *       // traiter content…
 *       cursor = blockEnd;
 *   }
 * @endcode
 *
 * @note Le pointeur retourné est un pointeur dans @p src ; la chaîne
 *       source ne doit pas être modifiée ou libérée pendant l'utilisation
 *       du résultat.
 */
const char* ParserXML::findBlock(const char* src, const char* tagName,
                                  const char** blockEnd) {
    char openTag[64], closeTag[64];
    snprintf(openTag,  sizeof(openTag),  "<%s",  tagName);
    snprintf(closeTag, sizeof(closeTag), "</%s>", tagName);

    /* Recherche du début de la balise ouvrante */
    const char* p = strstr(src, openTag);
    if (!p) return nullptr;

    /*
     * Discrimination : le caractère qui suit immédiatement le nom du tag
     * doit être un terminateur de nom valide pour éviter de confondre
     * "<button>" avec "<buttongroup>".
     */
    const char* after = p + strlen(openTag);
    if (*after != '>' && *after != ' ' && *after != '\n' && *after != '\r')
        return nullptr;

    /* Avancement jusqu'à la fin de la balise ouvrante (attributs inclus) */
    const char* content = strchr(p, '>');
    if (!content) return nullptr;
    content++;   /* Pointe sur le premier caractère du contenu du bloc */

    /* Recherche de la balise fermante */
    const char* end = strstr(content, closeTag);
    if (!end) return nullptr;

    /* Écriture de la position juste après la balise fermante */
    if (blockEnd) *blockEnd = end + strlen(closeTag);
    return content;
}

// ─────────────────────────────────────────────────────────────────
//  makeWidget
// ─────────────────────────────────────────────────────────────────

/**
 * @brief Crée et retourne le widget E2mmaWidgets correspondant à un bloc XML.
 *
 * Lecture des attributs communs à tous les widgets :
 * | Balise XML  | Attribut       | Défaut    |
 * |-------------|----------------|-----------|
 * | @c \<x\>   | position X     | 0         |
 * | @c \<y\>   | position Y     | 0         |
 * | @c \<width\>  | largeur     | 100 px    |
 * | @c \<height\> | hauteur     | 40 px     |
 * | @c \<color\>  | couleur de fond | #888888 |
 * | @c \<colortext\> | couleur du texte | #000000 |
 * | @c \<text\>  | étiquette     | ""        |
 * | @c \<hiden\> | visibilité    | false     |
 *
 * Selon la valeur de @p tagName, des attributs supplémentaires sont lus
 * (voir tableau dans ParserXML::makeWidget() dans l'en-tête).
 *
 * @par Attributs spécifiques slider
 * | Balise XML          | Signification         | Défaut |
 * |---------------------|-----------------------|--------|
 * | @c \<startvalue\>   | valeur minimale       | 0      |
 * | @c \<endvalue\>     | valeur maximale       | 100    |
 * | @c \<index\>        | valeur initiale       | 0      |
 * | @c \<colorindicator\> | couleur curseur     | #888888 |
 * | @c \<colorbackground\> | couleur fond      | 128,128,128 |
 *
 * @par Attributs spécifiques textarea
 * | Balise XML          | Signification         | Défaut |
 * |---------------------|-----------------------|--------|
 * | @c \<placeholder\>  | texte indicatif vide  | ""     |
 *
 * @note L'objet alloué avec @c new doit être libéré par l'appelant
 *       ou transféré à Userinterface::addWidget() qui en prend la propriété.
 */
E2mmaWidgets::Widget* ParserXML::makeWidget(const char* tagName, const char* block) {

    /* ── Attributs communs à tous les widgets ── */
    int x = getChildInt(block, "x");
    int y = getChildInt(block, "y");
    int w = getChildInt(block, "width",  100);
    int h = getChildInt(block, "height",  40);

    char colorStr[32]     = "#888888";
    char colorTextStr[32] = "#000000";
    char text[128]        = "";
    char hidden[8]        = "false";

    getChildText(block, "color",     colorStr,     sizeof(colorStr));
    getChildText(block, "colortext", colorTextStr, sizeof(colorTextStr));
    getChildText(block, "text",      text,          sizeof(text));
    getChildText(block, "hiden",     hidden,        sizeof(hidden));  /* Typo XML conservée volontairement */

    bool     isHidden  = (strcmp(hidden, "true") == 0);
    uint32_t color     = parseColor(colorStr,     0x888888);
    uint32_t colorText = parseColor(colorTextStr, 0x000000);

    /* ── Instanciation selon le type de widget ── */

    /**
     * @details **button** → PushButton
     * Bouton poussoir simple avec texte centré et couleur de fond configurable.
     */
    if (strcmp(tagName, "button") == 0) {
        return new E2mmaWidgets::PushButton(x, y, w, h, text, color, colorText, isHidden);
    }

    /**
     * @details **slider** → Slider
     * Curseur horizontal avec plage [startvalue, endvalue], valeur initiale
     * définie par @c \<index\>, et deux couleurs distinctes pour l'indicateur
     * et le fond de la piste.
     */
    if (strcmp(tagName, "slider") == 0) {
        int mn  = getChildInt(block, "startvalue", 0);
        int mx  = getChildInt(block, "endvalue",  100);
        int val = getChildInt(block, "index",       0);

        char colorInd[32] = "#888888";
        char colorBg[32]  = "128,128,128";
        getChildText(block, "colorindicator",  colorInd, sizeof(colorInd));
        getChildText(block, "colorbackground", colorBg,  sizeof(colorBg));

        return new E2mmaWidgets::Slider(x, y, w, h, mn, mx, val,
                                        text,
                                        parseColor(colorInd, 0x888888),
                                        parseColor(colorBg,  0x808080),
                                        isHidden);
    }

    /**
     * @details **label** → Label
     * Étiquette texte statique avec wrap automatique sur la largeur définie.
     */
    if (strcmp(tagName, "label") == 0) {
        return new E2mmaWidgets::Label(x, y, w, h, text, color, isHidden);
    }

    /**
     * @details **textarea** → TextArea
     * Zone de saisie monoligne avec texte initial et texte indicatif (placeholder).
     */
    if (strcmp(tagName, "textarea") == 0) {
        char placeholder[128] = "";
        getChildText(block, "placeholder", placeholder, sizeof(placeholder));
        return new E2mmaWidgets::TextArea(x, y, w, h, text, placeholder, isHidden);
    }

    /**
     * @details **switch** → Switch
     * Interrupteur à bascule ON/OFF (toggle). Pas d'attributs spécifiques
     * au-delà des attributs communs de position/taille/visibilité.
     */
    if (strcmp(tagName, "switch") == 0) {
        return new E2mmaWidgets::Switch(x, y, w, h, isHidden);
    }

    /**
     * @details **led** → Led
     * Indicateur lumineux circulaire, éteint par défaut (lv_led_off).
     * La couleur de fond (@c \<color\>) définit la teinte de la LED allumée.
     */
    if (strcmp(tagName, "led") == 0) {
        return new E2mmaWidgets::Led(x, y, w, h, color, isHidden);
    }

    /**
     * @details **keyboard** → Keyboard
     * Bouton « Clavier » qui affiche/masque un clavier virtuel LVGL au clic.
     * La position/taille définie dans le XML correspond au clavier déplié,
     * non au bouton déclencheur.
     */
    if (strcmp(tagName, "keyboard") == 0) {
        return new E2mmaWidgets::Keyboard(x, y, w, h, isHidden);
    }

    /* Tag non reconnu : diagnostic sur le port série, aucun widget créé */
    Serial.print("[XML] Balise inconnue : ");
    Serial.println(tagName);
    return nullptr;
}

// ─────────────────────────────────────────────────────────────────
//  parse  (point d'entrée principal)
// ─────────────────────────────────────────────────────────────────

/**
 * @brief Parse le buffer XML et injecte les widgets dans @p ui.
 *
 * Séquence d'exécution :
 *  1. Vérification des préconditions (@p xmlBuffer et @p ui non nuls).
 *  2. Suppression de tous les widgets existants (ui->clearWidgets()).
 *  3. Localisation du bloc @c \<ui\>…\</ui\> dans le buffer.
 *  4. Itération sur la liste ordonnée des types de widgets :
 *     @code
 *       label → slider → textarea → switch → led → display → keyboard → button
 *     @endcode
 *     Cet ordre garantit que les éléments de fond (labels, sliders) sont
 *     créés en premiers et donc dessinés sous les boutons dans la pile LVGL.
 *  5. Pour chaque type, boucle de recherche sur l'ensemble du bloc @c \<ui\>
 *     jusqu'à épuisement de toutes les occurrences.
 *  6. Chaque widget créé est passé à ui->addWidget() qui en prend l'ownership.
 *
 * @par Gestion des erreurs
 * - Si @p xmlBuffer ou @p ui est nul → retour immédiat @c -1.
 * - Si le bloc @c \<ui\> est absent → message série + retour @c -1.
 * - Si une balise de widget est mal formée → makeWidget() retourne @c nullptr
 *   et le widget est silencieusement ignoré (compteur non incrémenté).
 */
int ParserXML::parse(const char* xmlBuffer, Userinterface* ui) {
    if (!xmlBuffer || !ui) return -1;

    /* Nettoyage de l'interface avant chargement d'un nouveau fichier */
    ui->clearWidgets();
    int count = 0;

    /* Localisation du bloc racine <ui> qui contient tous les widgets */
    const char* uiEnd   = nullptr;
    const char* uiBlock = findBlock(xmlBuffer, "ui", &uiEnd);
    if (!uiBlock) {
        Serial.println("[XML] Bloc <ui> introuvable");
        return -1;
    }

    /*
     * Ordre d'affichage (profondeur LVGL) :
     *  - Fond   : label, slider, textarea, switch, led, display
     *  - Avant  : keyboard, button  (par-dessus les autres éléments)
     * Le tableau se termine par nullptr pour servir de sentinelle de boucle.
     */
    const char* widgetTypes[] = {
        "label", "slider", "textarea", "switch", "led", "display",
        "keyboard", "button", nullptr
    };

    /* Boucle sur chaque type de widget */
    for (int t = 0; widgetTypes[t] != nullptr; t++) {
        const char* tagName = widgetTypes[t];
        const char* cursor  = uiBlock;

        /*
         * Itération sur toutes les occurrences du type courant
         * dans le bloc <ui>. cursor avance après chaque bloc trouvé
         * pour éviter de reparser le même élément deux fois.
         */
        while (cursor < uiEnd) {
            const char* blockEnd     = nullptr;
            const char* blockContent = findBlock(cursor, tagName, &blockEnd);

            /* Plus de bloc de ce type, ou hors limites du <ui> */
            if (!blockContent || blockContent >= uiEnd) break;

            /* Création du widget et injection dans l'interface */
            E2mmaWidgets::Widget* w = makeWidget(tagName, blockContent);
            if (w) {
                ui->addWidget(w);   /* Transfert d'ownership */
                count++;
                Serial.print("[XML] + ");
                Serial.print(tagName);
            }

            /* Avancement du curseur au-delà du bloc traité */
            cursor = blockEnd;
        }
    }

    Serial.print("[XML] Total : ");
    Serial.println(count);
    return count;
}
