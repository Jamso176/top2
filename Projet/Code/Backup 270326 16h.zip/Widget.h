#ifndef WIDGET_H
#define WIDGET_H

#include <Arduino.h>
#include "lvgl.h"

namespace E2mmaWidgets {

enum WidgetType {
    WIDGET_PUSHBUTTON,
    WIDGET_SWITCH,
    WIDGET_SLIDER,
    WIDGET_LED,
    WIDGET_DISPLAY,
    WIDGET_LABEL,
    WIDGET_TEXTAREA,
    WIDGET_KEYBOARD,
    WIDGET_UNKNOWN
};

// ─── Classe de base ───────────────────────────────────────────────
class Widget {
protected:
    WidgetType widgetType;
    int        position[2];   // x, y
    int        size[2];       // w, h
    lv_obj_t*  lvObj;
    bool       hidden;

public:
    Widget(WidgetType type, int x, int y, int w, int h, bool hidden = false)
        : widgetType(type), lvObj(nullptr), hidden(hidden)
    {
        position[0] = x; position[1] = y;
        size[0]     = w; size[1]     = h;
    }
    virtual ~Widget() {}
    virtual void build(lv_obj_t* parent) = 0;
    lv_obj_t* getLvObj() const { return lvObj; }
};

// ─── PushButton ───────────────────────────────────────────────────
class PushButton : public Widget {
    char     _label[64];
    uint32_t _color;
    uint32_t _colorText;
public:
    PushButton(int x, int y, int w, int h,
               const char* label   = "BTN",
               uint32_t color      = 0x5562E7,
               uint32_t colorText  = 0x000000,
               bool hidden         = false)
        : Widget(WIDGET_PUSHBUTTON, x, y, w, h, hidden),
          _color(color), _colorText(colorText)
    {
        strncpy(_label, label ? label : "BTN", sizeof(_label) - 1);
        _label[sizeof(_label) - 1] = '\0';
    }

    void build(lv_obj_t* parent) override {
        lvObj = lv_button_create(parent);
        lv_obj_set_size(lvObj, size[0], size[1]);
        lv_obj_set_pos(lvObj, position[0], position[1]);
        lv_obj_set_style_bg_color(lvObj, lv_color_hex(_color), 0);
        lv_obj_set_style_border_width(lvObj, 0, 0);
        lv_obj_set_style_radius(lvObj, 6, 0);
        lv_obj_set_style_shadow_width(lvObj, 0, 0);

        lv_obj_t* lbl = lv_label_create(lvObj);
        lv_label_set_text(lbl, _label);
        lv_obj_set_style_text_color(lbl, lv_color_hex(_colorText), 0);
        lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
        lv_obj_center(lbl);

        if (hidden) lv_obj_add_flag(lvObj, LV_OBJ_FLAG_HIDDEN);
    }
};

// ─── Slider ───────────────────────────────────────────────────────
// Affiché tel quel à (x, y) avec (w, h) — le label texte est positionné
// séparément par le XML (c'est un <label> associé)
class Slider : public Widget {
    int      _min, _max, _val;
    char     _label[64];
    uint32_t _colorInd;
    uint32_t _colorBg;
public:
    Slider(int x, int y, int w, int h,
           int mn = 0, int mx = 100, int val = 0,
           const char* label    = "",
           uint32_t colorInd   = 0x5562E7,
           uint32_t colorBg    = 0x808080,
           bool hidden         = false)
        : Widget(WIDGET_SLIDER, x, y, w, h, hidden),
          _min(mn), _max(mx), _val(val),
          _colorInd(colorInd), _colorBg(colorBg)
    {
        strncpy(_label, label ? label : "", sizeof(_label) - 1);
        _label[sizeof(_label) - 1] = '\0';
    }

    void build(lv_obj_t* parent) override {
        // Label à gauche du slider (x-130 pour ne pas déborder)
        if (_label[0] != '\0') {
            lv_obj_t* lbl = lv_label_create(parent);
            lv_label_set_text(lbl, _label);
            lv_obj_set_style_text_color(lbl, lv_color_hex(_colorInd), 0);
            lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
            // Centré verticalement par rapport au slider
            lv_obj_set_pos(lbl, position[0] - 130, position[1] + (size[1] - 14) / 2);
        }

        // Slider à la position exacte du XML
        lvObj = lv_slider_create(parent);
        lv_obj_set_size(lvObj, size[0], size[1]);
        lv_obj_set_pos(lvObj, position[0], position[1]);
        lv_slider_set_range(lvObj, _min, _max);
        lv_slider_set_value(lvObj, _val, LV_ANIM_OFF);
        lv_obj_set_style_bg_color(lvObj, lv_color_hex(_colorBg),  LV_PART_MAIN);
        lv_obj_set_style_bg_color(lvObj, lv_color_hex(_colorInd), LV_PART_INDICATOR);
        lv_obj_set_style_bg_color(lvObj, lv_color_hex(_colorInd), LV_PART_KNOB);

        if (hidden) {
            lv_obj_add_flag(lvObj, LV_OBJ_FLAG_HIDDEN);
        }
    }
};

// ─── Label ───────────────────────────────────────────────────────
class Label : public Widget {
    char     _text[128];
    uint32_t _color;
public:
    Label(int x, int y, int w, int h,
          const char* text  = "",
          uint32_t color    = 0xCDD6F4,
          bool hidden       = false)
        : Widget(WIDGET_LABEL, x, y, w, h, hidden), _color(color)
    {
        strncpy(_text, text ? text : "", sizeof(_text) - 1);
        _text[sizeof(_text) - 1] = '\0';
    }

    void build(lv_obj_t* parent) override {
        lvObj = lv_label_create(parent);
        lv_label_set_text(lvObj, _text);
        lv_label_set_long_mode(lvObj, LV_LABEL_LONG_WRAP);
        lv_obj_set_width(lvObj, size[0]);
        lv_obj_set_pos(lvObj, position[0], position[1]);
        lv_obj_set_style_text_color(lvObj, lv_color_hex(_color), 0);
        lv_obj_set_style_text_font(lvObj, &lv_font_montserrat_14, 0);
        if (hidden) lv_obj_add_flag(lvObj, LV_OBJ_FLAG_HIDDEN);
    }
};

// ─── TextArea ────────────────────────────────────────────────────
// Champ de saisie numérique sans bordure ni curseur LVGL.
// Au tap → popup pavé numérique (0-9, ⌫, C, ✓).
// Un label séparé (hors textarea) affiche la valeur en temps réel
// pour contourner le rendu interne du textarea LVGL.
class TextArea : public Widget {

    struct NumpadCtx {
        lv_obj_t* value_label;   // label séparé qui affiche la valeur
        lv_obj_t* disp_label;    // label dans le popup (mis à jour à chaque touche)
        lv_obj_t* overlay;
        char      buf[64];       // valeur courante (chaîne brute)
    };

    char _text[128];
    char _placeholder[128];

    static void _update_both(NumpadCtx* ctx) {
        lv_label_set_text(ctx->value_label, ctx->buf[0] ? ctx->buf : ctx->buf); // force refresh
        lv_label_set_text(ctx->disp_label,  ctx->buf[0] ? ctx->buf : " ");
    }

    static void _close_numpad(NumpadCtx* ctx) {
        if (!ctx) return;
        // Synchroniser le label externe avec la valeur finale
        lv_label_set_text(ctx->value_label, ctx->buf[0] ? ctx->buf : "");
        if (ctx->overlay) { lv_obj_del(ctx->overlay); ctx->overlay = nullptr; }
        delete ctx;
    }

    static void _key_cb(lv_event_t* e) {
        NumpadCtx*  ctx = (NumpadCtx*)lv_event_get_user_data(e);
        lv_obj_t*   btn = lv_event_get_target_obj(e);
        const char* key = lv_label_get_text(lv_obj_get_child(btn, 0));

        if (strcmp(key, LV_SYMBOL_OK) == 0) {
            _close_numpad(ctx);
            return;
        } else if (strcmp(key, "C") == 0) {
            ctx->buf[0] = '\0';
        } else if (strcmp(key, LV_SYMBOL_BACKSPACE) == 0) {
            int len = strlen(ctx->buf);
            if (len > 0) ctx->buf[len - 1] = '\0';
        } else {
            // Limiter à 10 chiffres
            if (strlen(ctx->buf) < 10) strncat(ctx->buf, key, 1);
        }
        _update_both(ctx);
    }

    static void _tap_cb(lv_event_t* e) {
        lv_obj_t*   value_lbl = (lv_obj_t*)lv_event_get_user_data(e);
        lv_obj_t*   screen    = lv_obj_get_screen(value_lbl);

        NumpadCtx* ctx     = new NumpadCtx();
        ctx->value_label   = value_lbl;
        ctx->disp_label    = nullptr;
        ctx->overlay       = nullptr;
        // Initialiser buf avec la valeur actuelle du label
        strncpy(ctx->buf, lv_label_get_text(value_lbl), sizeof(ctx->buf) - 1);
        ctx->buf[sizeof(ctx->buf) - 1] = '\0';

        // ── Overlay ──────────────────────────────────────────────
        ctx->overlay = lv_obj_create(screen);
        lv_obj_set_size(ctx->overlay, LV_PCT(100), LV_PCT(100));
        lv_obj_set_pos(ctx->overlay, 0, 0);
        lv_obj_set_style_bg_color(ctx->overlay, lv_color_hex(0x000000), 0);
        lv_obj_set_style_bg_opa(ctx->overlay, 130, 0);
        lv_obj_set_style_border_width(ctx->overlay, 0, 0);
        lv_obj_set_style_radius(ctx->overlay, 0, 0);
        lv_obj_clear_flag(ctx->overlay, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_event_cb(ctx->overlay, [](lv_event_t* ev) {
            _close_numpad((NumpadCtx*)lv_event_get_user_data(ev));
        }, LV_EVENT_CLICKED, ctx);

        // ── Panel centré ─────────────────────────────────────────
        const int BTN_W     = 90;
        const int BTN_H     = 70;
        const int GAP       = 8;
        const int PAD       = 16;
        const int COLS      = 3;
        const int ROWS      = 4;
        const int DISP_H    = 52;
        const int CONFIRM_H = 56;
        int panel_w = COLS * BTN_W + (COLS - 1) * GAP + 2 * PAD;
        int panel_h = PAD + DISP_H + GAP
                    + ROWS * (BTN_H + GAP)
                    + CONFIRM_H + PAD;

        lv_obj_t* panel = lv_obj_create(ctx->overlay);
        lv_obj_set_size(panel, panel_w, panel_h);
        lv_obj_align(panel, LV_ALIGN_CENTER, 0, 0);
        lv_obj_set_style_bg_color(panel, lv_color_hex(0x313244), 0);
        lv_obj_set_style_border_width(panel, 0, 0);
        lv_obj_set_style_radius(panel, 12, 0);
        lv_obj_set_style_shadow_width(panel, 24, 0);
        lv_obj_set_style_shadow_color(panel, lv_color_hex(0x000000), 0);
        lv_obj_set_style_shadow_opa(panel, 180, 0);
        lv_obj_set_style_pad_all(panel, 0, 0);
        lv_obj_clear_flag(panel, LV_OBJ_FLAG_SCROLLABLE);
        // Bloquer propagation du clic vers l'overlay
        lv_obj_add_event_cb(panel, [](lv_event_t* ev){
            lv_event_stop_bubbling(ev);
        }, LV_EVENT_CLICKED, nullptr);

        // ── Zone d'affichage en haut ─────────────────────────────
        lv_obj_t* disp_bg = lv_obj_create(panel);
        lv_obj_set_size(disp_bg, panel_w - 2 * PAD, DISP_H);
        lv_obj_set_pos(disp_bg, PAD, PAD);
        lv_obj_set_style_bg_color(disp_bg, lv_color_hex(0x1E1E2E), 0);
        lv_obj_set_style_border_width(disp_bg, 0, 0);
        lv_obj_set_style_radius(disp_bg, 8, 0);
        lv_obj_set_style_pad_all(disp_bg, 8, 0);
        lv_obj_clear_flag(disp_bg, LV_OBJ_FLAG_SCROLLABLE);

        ctx->disp_label = lv_label_create(disp_bg);
        lv_label_set_text(ctx->disp_label, ctx->buf[0] ? ctx->buf : " ");
        lv_obj_set_style_text_color(ctx->disp_label, lv_color_hex(0xCDD6F4), 0);
        lv_obj_set_style_text_font(ctx->disp_label, &lv_font_montserrat_14, 0);
        lv_obj_align(ctx->disp_label, LV_ALIGN_RIGHT_MID, 0, 0);

        // ── Touches ──────────────────────────────────────────────
        const char* keys[ROWS][COLS] = {
            { "7", "8", "9" },
            { "4", "5", "6" },
            { "1", "2", "3" },
            { "C", "0", LV_SYMBOL_BACKSPACE }
        };
        int keys_y = PAD + DISP_H + GAP;

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                const char* k  = keys[r][c];
                lv_obj_t*   btn = lv_button_create(panel);
                lv_obj_set_size(btn, BTN_W, BTN_H);
                lv_obj_set_pos(btn, PAD + c * (BTN_W + GAP), keys_y + r * (BTN_H + GAP));
                lv_obj_set_style_border_width(btn, 0, 0);
                lv_obj_set_style_radius(btn, 8, 0);
                lv_obj_set_style_shadow_width(btn, 0, 0);

                uint32_t bg = 0x45475A;
                if      (strcmp(k, "C")                    == 0) bg = 0xE53935;
                else if (strcmp(k, LV_SYMBOL_BACKSPACE)    == 0) bg = 0xF9A825;
                lv_obj_set_style_bg_color(btn, lv_color_hex(bg),       0);
                lv_obj_set_style_bg_color(btn, lv_color_hex(0x585B70), LV_STATE_PRESSED);

                lv_obj_t* lbl = lv_label_create(btn);
                lv_label_set_text(lbl, k);
                lv_obj_set_style_text_color(lbl, lv_color_hex(0xCDD6F4), 0);
                lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
                lv_obj_center(lbl);
                lv_obj_add_event_cb(btn, _key_cb, LV_EVENT_CLICKED, ctx);
            }
        }

        // ── Bouton ✓ ─────────────────────────────────────────────
        int confirm_y = keys_y + ROWS * (BTN_H + GAP);
        lv_obj_t* btnOk = lv_button_create(panel);
        lv_obj_set_size(btnOk, panel_w - 2 * PAD, CONFIRM_H);
        lv_obj_set_pos(btnOk, PAD, confirm_y);
        lv_obj_set_style_bg_color(btnOk, lv_color_hex(0x89B4FA), 0);
        lv_obj_set_style_bg_color(btnOk, lv_color_hex(0xB4BEFE), LV_STATE_PRESSED);
        lv_obj_set_style_border_width(btnOk, 0, 0);
        lv_obj_set_style_radius(btnOk, 8, 0);
        lv_obj_set_style_shadow_width(btnOk, 0, 0);
        lv_obj_t* lblOk = lv_label_create(btnOk);
        lv_label_set_text(lblOk, LV_SYMBOL_OK);
        lv_obj_set_style_text_color(lblOk, lv_color_hex(0x1E1E2E), 0);
        lv_obj_set_style_text_font(lblOk, &lv_font_montserrat_14, 0);
        lv_obj_center(lblOk);
        lv_obj_add_event_cb(btnOk, _key_cb, LV_EVENT_CLICKED, ctx);
    }

public:
    TextArea(int x, int y, int w, int h,
             const char* text        = "",
             const char* placeholder = "",
             bool hidden             = false)
        : Widget(WIDGET_TEXTAREA, x, y, w, h, hidden)
    {
        strncpy(_text,        text        ? text        : "", sizeof(_text) - 1);
        strncpy(_placeholder, placeholder ? placeholder : "", sizeof(_placeholder) - 1);
        _text[sizeof(_text) - 1]               = '\0';
        _placeholder[sizeof(_placeholder) - 1] = '\0';
    }

    void build(lv_obj_t* parent) override {
        // ── Conteneur de fond (remplace le textarea LVGL natif) ──
        // On utilise un lv_obj + lv_label pour avoir un affichage
        // 100 % propre sans bordure/curseur/outline LVGL.
        lv_obj_t* box = lv_obj_create(parent);
        lv_obj_set_size(box, size[0], size[1]);
        lv_obj_set_pos(box, position[0], position[1]);
        lv_obj_set_style_bg_color(box, lv_color_hex(0x313244), 0);
        lv_obj_set_style_border_width(box, 0, 0);
        lv_obj_set_style_outline_width(box, 0, 0);
        lv_obj_set_style_outline_width(box, 0, LV_STATE_FOCUSED);
        lv_obj_set_style_radius(box, 6, 0);
        lv_obj_set_style_pad_left(box, 8, 0);
        lv_obj_set_style_pad_right(box, 8, 0);
        lv_obj_clear_flag(box, LV_OBJ_FLAG_SCROLLABLE);

        // Label affichant la valeur (ou le placeholder si vide)
        lv_obj_t* lbl = lv_label_create(box);
        lv_label_set_text(lbl, _text[0] ? _text : _placeholder);
        lv_obj_set_style_text_color(lbl,
            _text[0] ? lv_color_hex(0xCDD6F4) : lv_color_hex(0x6C7086), 0);
        lv_obj_set_style_text_font(lbl, &lv_font_montserrat_14, 0);
        lv_obj_align(lbl, LV_ALIGN_LEFT_MID, 0, 0);

        lvObj = box;

        // Ouvrir le pavé au tap sur le box — on passe lbl comme user_data
        lv_obj_add_flag(box, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(box, _tap_cb, LV_EVENT_CLICKED, lbl);

        if (hidden) lv_obj_add_flag(box, LV_OBJ_FLAG_HIDDEN);
    }
};

// ─── Switch ───────────────────────────────────────────────────────
class Switch : public Widget {
public:
    Switch(int x, int y, int w, int h, bool hidden = false)
        : Widget(WIDGET_SWITCH, x, y, w, h, hidden) {}

    void build(lv_obj_t* parent) override {
        lvObj = lv_switch_create(parent);
        lv_obj_set_size(lvObj, size[0], size[1]);
        lv_obj_set_pos(lvObj, position[0], position[1]);
        if (hidden) lv_obj_add_flag(lvObj, LV_OBJ_FLAG_HIDDEN);
    }
};

// ─── Led ─────────────────────────────────────────────────────────
class Led : public Widget {
    uint32_t _color;
public:
    Led(int x, int y, int w, int h,
        uint32_t color = 0x00FF00,
        bool hidden    = false)
        : Widget(WIDGET_LED, x, y, w, h, hidden), _color(color) {}

    void build(lv_obj_t* parent) override {
        lvObj = lv_led_create(parent);
        lv_obj_set_size(lvObj, size[0], size[1]);
        lv_obj_set_pos(lvObj, position[0], position[1]);
        lv_led_set_color(lvObj, lv_color_hex(_color));
        lv_led_off(lvObj);
        if (hidden) lv_obj_add_flag(lvObj, LV_OBJ_FLAG_HIDDEN);
    }
};

// ─── Keyboard ────────────────────────────────────────────────────
class Keyboard : public Widget {
    lv_obj_t* _keyboard;
public:
    Keyboard(int x, int y, int w, int h, bool hidden = false)
        : Widget(WIDGET_KEYBOARD, x, y, w, h, hidden), _keyboard(nullptr) {}

    void build(lv_obj_t* parent) override {
        lv_obj_t* btn = lv_button_create(parent);
        lv_obj_set_size(btn, 120, 40);
        lv_obj_set_pos(btn, position[0], position[1]);
        lv_obj_set_style_bg_color(btn, lv_color_hex(0x89B4FA), 0);
        lv_obj_t* lbl = lv_label_create(btn);
        lv_label_set_text(lbl, "Clavier");
        lv_obj_center(lbl);
        lvObj = btn;

        _keyboard = lv_keyboard_create(parent);
        lv_obj_set_size(_keyboard, size[0], size[1]);
        lv_obj_add_flag(_keyboard, LV_OBJ_FLAG_HIDDEN);

        lv_obj_add_event_cb(btn, [](lv_event_t* e) {
            lv_obj_t* kb = (lv_obj_t*)lv_event_get_user_data(e);
            if (lv_obj_has_flag(kb, LV_OBJ_FLAG_HIDDEN))
                lv_obj_clear_flag(kb, LV_OBJ_FLAG_HIDDEN);
            else
                lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
        }, LV_EVENT_CLICKED, _keyboard);

        if (hidden) lv_obj_add_flag(btn, LV_OBJ_FLAG_HIDDEN);
    }
};

} // namespace E2mmaWidgets

#endif // WIDGET_H
