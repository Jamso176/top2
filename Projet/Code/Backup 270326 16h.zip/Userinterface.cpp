#include "Userinterface.h"

Userinterface::Userinterface()
    : _widgetCount(0), _screen(nullptr)
{
    for (int i = 0; i < MAX_WIDGETS; i++) _widgets[i] = nullptr;
}

Userinterface::~Userinterface() {
    clearWidgets();
}

void Userinterface::begin() {
    // Ne rien créer ici — le screen est créé à la demande dans clearWidgets/addWidget
    Serial.println("[UI] Initialise");
}

void Userinterface::tick() {
    lv_timer_handler();
}

void Userinterface::addWidget(E2mmaWidgets::Widget* widget) {
    if (!widget || _widgetCount >= MAX_WIDGETS) return;
    // Créer le screen la première fois qu'un widget est ajouté
    if (!_screen) {
        _screen = lv_obj_create(NULL);
        lv_obj_set_style_bg_color(_screen, lv_color_hex(0x1E1E2E), 0);
        lv_obj_set_style_pad_all(_screen, 0, 0);
    }
    widget->build(_screen);
    _widgets[_widgetCount++] = widget;
}

void Userinterface::clearWidgets() {
    for (int i = 0; i < _widgetCount; i++) {
        delete _widgets[i];
        _widgets[i] = nullptr;
    }
    _widgetCount = 0;

    if (_screen) {
        lv_obj_del(_screen);
        _screen = nullptr;
    }
    Serial.println("[UI] Widgets effaces");
}
