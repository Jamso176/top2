#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include <Arduino.h>
#include <Arduino_USBHostMbed5.h>
#include <FATFileSystem.h>
// NE PAS inclure "mbed.h" directement — déjà transitif via Arduino.h
// et provoque un conflit de PinMode + FileSystem avec mbed::FileSystem

#define USB_MOUNT_POINT  "/usb"
#define MAX_FILES        64
#define MAX_FILENAME     128
#define MAX_CONTENT      32384

// ─── Classe bas niveau USB ────────────────────────────────────────

class USBFileSystem {
public:
    USBFileSystem();
    ~USBFileSystem();

    bool        begin(unsigned long timeoutMs = 15000);
    bool        isReady() const;
    bool        isConnected();

    int         listFiles(const char* dir = USB_MOUNT_POINT);
    const char* getFileName(int i) const;
    const char* getFilePath(int i) const;
    int         getFileCount() const;

    bool        readFile(const char* path, char* outBuf, size_t bufSize);
    void        unmount();

private:
    USBHostMSD*         _msd;
    mbed::FATFileSystem _fs;
    bool                _ready;
    int                 _fileCount;

    char _fileNames[MAX_FILES][MAX_FILENAME];
    char _filePaths[MAX_FILES][MAX_FILENAME + 8];
};

// ─── Classe E2MMA — renommée E2FileSystem pour éviter le conflit
//     avec mbed::FileSystem inclus transitoirement via Arduino.h ──

class E2FileSystem {
public:
    E2FileSystem();
    ~E2FileSystem();

    void begin();

    USBFileSystem& usb();

    bool        mount(unsigned long timeoutMs = 15000);
    void        unmount();
    bool        isReady()     const;
    bool        isConnected();

    int         listFiles(const char* dir = USB_MOUNT_POINT);
    const char* getFileName(int i)  const;
    const char* getFilePath(int i)  const;
    int         getFileCount()      const;
    bool        readFile(const char* path, char* outBuf, size_t bufSize);

private:
    USBFileSystem _usb;
};

#endif // FILESYSTEM_H
