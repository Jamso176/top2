#ifndef E2MMA_H
#define E2MMA_H

// Forward declarations — les headers concrets sont inclus dans E2MMA.cpp
class ParserXML;
class CurvePlotting;
class E2FileSystem;
class Io;
class Userinterface;

class E2mma {

protected:
    ParserXML*      parserXML;
    CurvePlotting*  curvePlotting;
    E2FileSystem*   fileSystem;
    Io*             io;
    Userinterface*  userinterface;

public:
    E2mma();
    virtual ~E2mma();

    virtual void setup();
    virtual void run() = 0;

    E2FileSystem*   getFileSystem()    { return fileSystem; }
    Io*             getIo()            { return io; }
    Userinterface*  getUserInterface() { return userinterface; }
};

#endif // E2MMA_H
